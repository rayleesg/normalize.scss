#### normalize.scss v3.0.3 : March 31, 2015

* Remove unnecessary vendor prefixes.
* Add main property.


#### normalize.scss v3.0.2 : February 27, 2015

* Only alter `background-color` of links in IE 10.
* Add `menu` element to HTML5 display definitions.


#### normalize.scss v3.0.1 : May 8, 2014

* Add or remove any part of code of normalize.css
* Add or remove explanatory comments
* Add or remove support for ie7
